#include <iostream>

class String
{
public:
	String(const char* s) {}
};

void foo(String s) {}

int main()
{
	String s1 = "Hello";
	String s2("Hello");

	foo("Hello");

	const String& r1 = "Hello";
	const String& r2 = String("Hello");
}