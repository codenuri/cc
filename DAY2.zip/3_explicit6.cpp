
class istream
{
public:
	bool fail() { return true; }
};

istream cin;

int main()
{
	if (cin)
	{

	}
}