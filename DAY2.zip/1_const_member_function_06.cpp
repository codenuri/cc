class Object
{
public:
	void f1(int n)       {}
	void f1(int n) const {}
};

int main()
{
	Object obj;
	const Object constObj;

	obj.f1(3);
	constObj.f1(3);
}