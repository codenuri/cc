﻿// ES.47: Use nullptr rather than 0 or NULL 

int main()
{
	int* p1 = 0;
	int* p2 = nullptr;
}
