#include <iostream>
#include <thread>

void foo(int* p) {}

int main()
{
	std::thread t(&foo, 0);

	t.join();
}