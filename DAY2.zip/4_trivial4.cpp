#include <iostream>
#include <type_traits>

// C90. memset, memcpy �� �������� ����!

class Test
{
	int data;
public:
	virtual void foo() {}
};

void init(Test* p)
{
	memset(p, 0, sizeof(Test));
}

int main()
{
	Test* p = new Test;

	init(p);
	p->foo();

	delete p;
}