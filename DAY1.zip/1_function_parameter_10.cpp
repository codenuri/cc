#include <vector>
#include <iostream>

// "function" as function parameter

bool foo(int n) { return n % 3 == 0; }


template<typename T>
T find_if(T first, T last, ? )
{
	// ......
	return first;
}

int main()
{
	std::vector<int> v{ 1,2,3,4,5 };
	find_if(v.begin(), v.end(), foo);
}