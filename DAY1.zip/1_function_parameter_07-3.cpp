#include <iostream>
#include <string>

class Person
{
	std::string name;
	std::string address;
public:
	void set(const std::string& n, const std::string& a) 
	{ 
		name = n; 
		address = a;
	}
};

int main()
{
	Person p;

	std::string s1 = "lee";
	std::string s2 = "seoul";

	p.set(s1, s2);

}