#include <iostream>

template<typename T> class vector
{
	T* buff;
	int size;
public:
	vector(int sz) : buff(new T[sz]), size(sz) {}

	~vector() { delete[] buff; }
};
int main()
{
	int n1 = 0;

	vector<int> v(10);

	v[0] = 0;
	n1 = v[0];
}