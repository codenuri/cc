#include <iostream>

// in-parameter 
// #1. user define type

struct Rect
{
	int left, top, right, bottom;
};

// ���ڸ� �б⸸ �Ұ��̶��
void bad1(Rect rc) {}

int main()
{
	Rect rc;
	bad1(rc);
}
