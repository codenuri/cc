#include <vector>
#include <iostream>


class Functor
{
public:
	bool operator()() &  { std::cout << "lvalue object" << std::endl; return true; }
	bool operator()() && { std::cout << "rvalue object" << std::endl; return true;}
};

int main()
{
	Functor f; f();
	Functor()();
}
