#include <iostream>

// ������ ����

int main()
{
	int v1 = 10, v2 = 10;

	auto f1 = [](int a, int b) { return a + b; };

	//======================================================
	auto f2 = [v1, v2](int a, int b) { return a + b + v1 + v2; };

	//=======================================================
	auto f3 = [&v1, &v2](int a, int b) { v1 = 100;  return a + b + v1 + v2; };

}