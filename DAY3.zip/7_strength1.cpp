// F.4: If a function might have to be evaluated at compile time, declare it constexpr
//
// F.5: If a function is very small and time - critical, declare it inline

template<typename T>
T max1(T lhs, T rhs)
{
	return lhs < rhs ? rhs : lhs;
}

int main()
{
	int ret1 = max1(1, 2); 
}



