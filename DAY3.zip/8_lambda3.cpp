#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>

// local function

int main()
{
	int add(int a, int b) 
	{ 
		return a + b; 
	}; 


}